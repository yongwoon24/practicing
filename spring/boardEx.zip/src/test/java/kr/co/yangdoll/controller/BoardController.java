package kr.co.yangdoll.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.co.yangdoll.domain.BoardVO;
import kr.co.yangdoll.service.BoardService;

@Controller
@RequestMapping("/board/")
public class BoardController {
	@Autowired
	BoardService service;
	
	@RequestMapping("/list")
	public String list(Model mo) {
		List<BoardVO> list =service.getBoardList();
		mo.addAttribute("list", list);
		return "/board/list"; //     => /WEB-INF  /board/list  .jsp
	}
	
	@RequestMapping(value ="/board/register" )
	@GetMapping("/register") //  /board/ + /register => /board//register
	public String registerForm() {
		return "/board/regForm";
	}
	
	@RequestMapping(value ="/board/registerproc")
//	@PostMapping(value ="register")  // => /board/register
	public String register(BoardVO vo) {
		int result = service.insertBoard(vo, false);
		System.out.println(result + "개의 게시글 입력되었습니다.");
		return "redirect:/board/list";
	}
	
	@RequestMapping("/get")
	public String getBoard(int bno, Model model) {
		model.addAttribute("vo", service.getBoard(bno));
		return "/board/detail";
	}
	
	@PostMapping("modify")
	public String modify(BoardVO vo) {
		int result = service.updateBoard(vo);
		return "redirect:/board/list";
	}
	

}
