package kr.co.yangdoll.domain;

import lombok.Data;

@Data
public class SearchVO {
	int searchNum;
	String searchTitle;
	
}
