package kr.co.yangdoll.util;

public class PageCalcu {
	private int start = 0;
	private int end = 10;
	public PageCalcu() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PageCalcu(int start, int end) {
		super();
		this.start = start;
		this.end = end;
	}
	public int getStart() {
		return start;
	}
	public int getEnd() {
		return end;
	}
	
	
	
}
