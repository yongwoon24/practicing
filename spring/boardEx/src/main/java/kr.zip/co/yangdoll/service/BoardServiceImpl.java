package kr.co.yangdoll.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.yangdoll.domain.BoardVO;
import kr.co.yangdoll.persistence.BoardMapper;

//@Service
public class BoardServiceImpl implements BoardService {
	@Autowired
	BoardMapper boardMapper;
	
	@Override
	public int insertBoard(BoardVO vo, boolean selectKey) {
		if ( selectKey) {
			boardMapper.insertBoardGetBno(vo);
		}
		return boardMapper.insertBoard(vo);
	}

	@Override
	public int deleteBoard(Integer bno) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int updateBoard(BoardVO vo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public BoardVO getBoard(Integer bno) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BoardVO> getBoardList() {
		// TODO Auto-generated method stub
		return null;
	}

}
